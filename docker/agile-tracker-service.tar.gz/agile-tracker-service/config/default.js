module.exports={
  port: 3000, //测试环境监听端口
  mongodb: 'mongodb://mongodb/agiletracker',//mongodb地址
  /*
    ALL: new Level(Number.MIN_VALUE, "ALL"),
    TRACE: new Level(5000, "TRACE"),
    DEBUG: new Level(10000, "DEBUG"),
    INFO: new Level(20000, "INFO"),
    WARN: new Level(30000, "WARN"),
    ERROR: new Level(40000, "ERROR"),
    FATAL: new Level(50000, "FATAL"),
    MARK: new Level(9007199254740992, "MARK"), // 2^53
    OFF: new Level(Number.MAX_VALUE, "OFF")
  */
  autoIndex: true,
  loggerLevel: 'INFO',
  session: {
    key: 'agiletracker',
    secret: 'websiteforwisdplat',
    maxAge: 1000*60*60*24*180,
    httpOnly: false,
    rolling: true
  },
  status: {
    commited: ['Ready for testing', 'QA Verification', 'Closed', 'Done'],
    done: ['QA Verification', 'Closed', 'Done'],
    movein: 'movein',
    moveout: 'moveout',
    initial: 'initial'
  },
  default: {
    jql: 'project = {module} AND ((fixVersion in ({release}) OR labels in ({release}_Candidate)) AND type=story AND sprint in (openSprints()) ) ORDER BY Rank ASC'
  }
}
  